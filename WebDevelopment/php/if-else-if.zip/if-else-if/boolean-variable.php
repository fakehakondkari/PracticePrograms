<?php

$status = TRUE;
if ($status) {
  echo "The student has passed";
} else {
  echo "The student has failed";
}
?>