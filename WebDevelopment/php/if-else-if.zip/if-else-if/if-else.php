<?php

$marks = 50;
if ($marks >= 40) {
  echo "The student has passed";
} else {
  echo "The student has failed";
}
?>