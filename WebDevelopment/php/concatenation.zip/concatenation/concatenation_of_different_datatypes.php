<!DOCTYPE html>
<html>
    <head>
        <title>Variables, Data types and Operators</title>
    </head>
    <body>
        <?php
        $var1 = 18;
        $var2 = 12;
        echo "The value of first variable is " . $var1 . " and the value of second variable is " . $var2;
        ?>
    </body>
</html>