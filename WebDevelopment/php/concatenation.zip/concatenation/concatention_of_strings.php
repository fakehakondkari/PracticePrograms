<!DOCTYPE html>
<html>
    <head>
        <title>Variables, Data types and Operators</title>
    </head>
    <body>
        <?php
        $var1 = "Hello";
        $var2 = "Internshala";
        echo $var1 . $var2;
        ?>
    </body>
</html>