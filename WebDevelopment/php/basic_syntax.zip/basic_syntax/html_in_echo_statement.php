<!DOCTYPE html>
<html>
    <head>
        <title>PHP Syntax</title>
    </head>
    <body>
        <?php
        // This is a single line comment
        echo "<h1>I am the Batman!</h1>";
        ?>
    </body>
</html>
