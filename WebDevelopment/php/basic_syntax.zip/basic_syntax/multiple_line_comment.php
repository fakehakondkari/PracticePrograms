<!DOCTYPE html>
<html>
    <head>
        <title>PHP Syntax</title>
    </head>
    <body>
        <?php
        // This is a single line comment
        echo "I am the Batman!";
        /* This is a multi line comment
          I.e. it is used to write comments in two or more lines */
        ?>
    </body>
</html>