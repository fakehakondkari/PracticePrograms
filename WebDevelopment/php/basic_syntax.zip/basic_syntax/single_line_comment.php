<!DOCTYPE html>
<html>
    <head>
        <title>PHP Syntax</title>
    </head>
    <body>
        <?php
        //This is a single line comment
        echo"I am the Batman!";
        ?>
    </body>
</html>