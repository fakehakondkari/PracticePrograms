<!DOCTYPE html>
<html>
    <head>
        <title>Arrays</title>
    </head>
    <body>
        <?php
        $numbers = array("first_number" => 18, "second_number" => 12);
        print_r($numbers);
        ?>
    </body>
</html>