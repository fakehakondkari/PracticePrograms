<!DOCTYPE html>
<html>
    <head>
        <title>Arrays</title>
    </head>
    <body>
        <?php
        $numbers = array(18, 12);
        $sum = $numbers[0] + $numbers[1];
        echo "Sum of two variables is " . $sum . ".";
        ?>
    </body>
</html>