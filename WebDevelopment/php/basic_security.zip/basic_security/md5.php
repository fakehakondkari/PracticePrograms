<?php

$str = "Hello";
echo md5($str);
?> 