<?php

$counter = 1;
while ($counter <= 5) {
  echo $counter . "<br>";
  $counter++;
}
?>
