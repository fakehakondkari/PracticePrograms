<?php

$marks = array("first_number" => 4, "second_number" => 8);
foreach ($marks as $mark_index => $mark_value) {
  echo "The index is $mark_index, the value is $mark_value <br/>";
}
?>  