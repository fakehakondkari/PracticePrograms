<?php

$marks = array(4, 8, 15, 16, 23, 42);
foreach ($marks as $mark) {
  echo $mark . ", ";
}
?>