<?php

for ($counter = 1; $counter <= 5; $counter++) {
  echo $counter . "<br>";
}
?>