
// Initialize Firebase

var config = {
    apiKey: "AIzaSyAtBkxy9oncYz0y0WN5mjKwG_eRYEecSQI",
    authDomain: "ionic-2e7dc.firebaseapp.com",
    databaseURL: "https://ionic-2e7dc.firebaseio.com",
    projectId: "ionic-2e7dc",
    storageBucket: "ionic-2e7dc.appspot.com",
    messagingSenderId: "736391449543"
  };
  firebase.initializeApp(config);